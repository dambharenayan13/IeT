import React from 'react';

class LifecycleDemo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0,
      message: 'Component is mounting...'
    };
    console.log('Constructor: Component is being constructed');
  }

  componentDidMount() {
    console.log('componentDidMount: Component has mounted');
    this.setState({ message: 'Component has mounted!' });
  }

  shouldComponentUpdate(nextProps, nextState) {
    console.log('shouldComponentUpdate: Deciding if component should update');
    return true; // Return false to prevent update
  }

  componentDidUpdate(prevProps, prevState) {
    console.log('componentDidUpdate: Component did update');
    if (prevState.count !== this.state.count) {
      console.log(`Count changed from ${prevState.count} to ${this.state.count}`);
      this.setState({ message: `Count updated to ${this.state.count}` });
    }
  }

  componentWillUnmount() {
    console.log('componentWillUnmount: Component is about to unmount');
    alert('Component will unmount now!');
  }

  increment = () => {
    this.setState(prevState => ({ count: prevState.count + 1 }));
  };

  render() {
    console.log('Render: Component is rendering');
    return (
      <div>
        <h2>{this.state.message}</h2>
        <p>Count: {this.state.count}</p>
        <button onClick={this.increment}>Increment Count</button>
      </div>
    );
  }
}

export default LifecycleDemo;

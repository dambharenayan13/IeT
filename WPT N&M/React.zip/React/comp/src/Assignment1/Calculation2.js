export default function Calculation2(props) {
  let num1 = Number(props.num1);  
  let num2 = Number(props.num2);
  let operation = props.operation;
  let sum = 0;

  switch (operation) {
    case "Addition":
      sum = num1 + num2;
      break;
    case "Subtraction":
      sum = num1 - num2;
      break;
    case "Multiplication":
      sum = num1 * num2;
      break;
    case "Division":
      sum = num2 !== 0 ? num1 / num2 : "Cannot divide by zero";
      break;
    default:
      sum = "Enter the operation first";
  }

  return (
    <>
      <h1>Calculation is : {sum}</h1>
    </>
  );
}

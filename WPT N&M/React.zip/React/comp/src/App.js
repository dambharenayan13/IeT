import React, { useState } from 'react';
import Calculation2 from './Assignment1/Calculation2';
import Factorial from './Assignment1/Factorial';
import LifecycleDemo from './Assignment2/ClassComponentLifeCycle';
import RadioButton from './Assignment3/RadioButton';
import UserDetails from './Assignment4/Comp.js';


function App() {

  const [show, setShow] = useState(true);

  return (
    <div className="App">
      <h1>Main App Component</h1>
      <Calculation2 num1={10} num2={5} operation="Addition" />
      <Calculation2 num1={10} num2={5} operation="Subtraction" />
      <Calculation2 num1={10} num2={5} operation="Multiplication" />
      <Calculation2 num1={10} num2={5} operation="Division" />
      
      <Factorial number={5} />

       <h1>React Lifecycle Demo</h1>
      <button onClick={() => setShow(!show)}>
        {show ? 'Unmount LifecycleDemo' : 'Mount LifecycleDemo'}
      </button>
      {show && <LifecycleDemo />}
      
      <RadioButton/>
      
      <h1>Main Application</h1>
      <UserDetails />
      
    </div>
  );
}

export default App;

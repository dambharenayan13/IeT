const { add } = require('./calc');

const result = add(5, 9);
console.log('Result:', result);  
    
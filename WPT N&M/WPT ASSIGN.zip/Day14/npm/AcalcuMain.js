
const calc = require('./calcu');


const result = calc.add(5, 7);
console.log(`Addition of 5 & 7 = ${result}`);

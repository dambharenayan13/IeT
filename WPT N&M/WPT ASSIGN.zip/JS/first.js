let a = 50;
console.log(a);

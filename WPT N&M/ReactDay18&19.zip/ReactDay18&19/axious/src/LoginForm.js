import { useState } from "react";

export default function LoginForm() {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [submitted, setSubmitted] = useState(false);

    function handleSubmit(e) {
        e.preventDefault(); 
        setSubmitted(true);
    }

    return (
        <div>
            <h3>Login Form</h3>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                /><br />

            <br/>

                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                /><br />
                <br/>

                <input type="submit" value="Login" />
            </form>

            {submitted && (
                <div>
                    <p>Username: {username}</p>
                    <p>Password: {password}</p>
                </div>
            )}
        </div>
    );
}

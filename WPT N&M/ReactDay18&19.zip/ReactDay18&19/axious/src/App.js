import React, { useState } from 'react';
import logo from './logo.svg';
import './App.css';
//import useRefEx from './useRef';
import Table from './json';
import PasswordGenerator from './password';
import LoginForm from './LoginForm';

function App(){
 

  return (
    <div>
       <Table/>
       
     <PasswordGenerator/>

      <LoginForm/>

    

    
    </div>
  );
}

export default App;

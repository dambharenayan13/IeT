import React, { useState } from "react";

function Counter2() {
  const [count, setCount] = useState(0);

  if (count > 3) {
    throw new Error("Counter2 crashed because count is greater than 3");
  }

  return (
    <div>
      <h3>Counter 2: {count}</h3>
      <button onClick={() => setCount(c => c + 1)}>Increment Counter2</button>
    </div>
  );
}

export default Counter2;

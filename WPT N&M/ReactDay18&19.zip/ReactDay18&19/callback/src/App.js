import React from "react";
import ErrorBoundary from "./errorboundry";
import Counter1 from "./Counter1";
import Counter2 from "./Counter2";
import PasswordGenerator from "./passwordgenerator";
function App() {
  return (
    <div>
      <h1>React Error Boundary Demo</h1>
      <ErrorBoundary>
        <Counter1 />
      </ErrorBoundary>
      <ErrorBoundary>
        <Counter2 />
      </ErrorBoundary>
      <h1>Generate Password</h1>
      <PasswordGenerator/>
    </div>
  );
}

export default App;

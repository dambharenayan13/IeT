import React, { useState } from "react";

function Counter1() {
  const [count, setCount] = useState(0);

  if (count > 5) {
    throw new Error("Counter1 crashed because count is greater than 5");
  }

  return (
    <div>
      <h3>Counter 1: {count}</h3>
      <button onClick={() => setCount(c => c + 1)}>Increment Counter1</button>
    </div>
  );
}

export default Counter1;

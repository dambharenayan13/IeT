import React, { createContext, useContext } from "react";

const Context = createContext();

const GrandChild = () => {
  const context = useContext(Context);
  return <h3>{context.message}</h3>;
};

const Child = () => <GrandChild />;

export default function AppContext() {
  const data = { message: "Hello from useContext!" };
  return (
    <Context.Provider value={data}>
      <h2>useContext Hook Example</h2>
      <Child />
    </Context.Provider>
  );
}

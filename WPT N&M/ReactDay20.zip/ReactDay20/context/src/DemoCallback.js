import React, { useCallback, useState } from "react";

export default function DemoUseCallback() {
  const [user, setUser] = useState({ count: 0, number: 0 });

  const incCount = useCallback(() => {
    setUser((prev) => ({ ...prev, count: prev.count + 1 }));
  }, []);

  const decCount = useCallback(() => {
    setUser((prev) => ({ ...prev, count: prev.count - 1 }));
  }, []);

  const incNumber = useCallback(() => {
    setUser((prev) => ({ ...prev, number: prev.number + 1 }));
  }, []);

  return (
    <div>
      <h2>useCallback Example with Previous Object</h2>
      <button onClick={incCount}>Increase Count</button>{" "}
      <button onClick={decCount}>Decrease Count</button>{" "}
      <button onClick={incNumber}>Increase Number</button>
      <h3>Count: {user.count}</h3>
      <h3>Number: {user.number}</h3>
    </div>
  );
}

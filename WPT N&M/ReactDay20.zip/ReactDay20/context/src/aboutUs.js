import React from "react";

export default function AboutUs() {
  return (
    <div>
      <h2>About Us</h2>
      <p>This is the About Us page containing basic information.</p>
    </div>
  );
}

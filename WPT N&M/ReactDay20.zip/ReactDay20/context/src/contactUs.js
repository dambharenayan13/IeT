import React from "react";

export default function Contact() {
  return (
    <div>
      <h2>Contact Us</h2>
      <p>Email: info@ietpune.com</p>
      <p>Address: IET Pune</p>
    </div>
  );
}
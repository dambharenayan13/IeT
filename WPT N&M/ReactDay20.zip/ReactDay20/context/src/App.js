import './App.css';
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Home from './home';
import AboutUs from './aboutUs';
import Contact from './contactUs';
import DemoUseCallback from './DemoCallback';
import AppContext from './contexthook';


export default function App() {
  return (
    <BrowserRouter>
      <nav style={{ backgroundColor: "blue", padding: "10px" }}>
        <ul style={{ listStyle: "none", display: "flex", gap: "20px" }}>
          <li><Link to="/" style={linkStyle}>Home</Link></li>
          <li><Link to="/about" style={linkStyle}>About Us</Link></li>
          <li><Link to="/contact" style={linkStyle}>Contact</Link></li>
          <li><Link to="/callback" style={linkStyle}>useCallback Demo</Link></li>
          <li><Link to="/context" style={linkStyle}>useContext Demo</Link></li>
        </ul>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/callback" element={<DemoUseCallback />} />
        <Route path="/context" element={<AppContext />} />
      </Routes>
    </BrowserRouter>
  );
}

const linkStyle = {
  textDecoration: "none",
  color: "white",
  fontSize: "18px",
  fontWeight: "bold",
};


